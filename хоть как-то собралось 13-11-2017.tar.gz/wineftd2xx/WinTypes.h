#ifndef __WINDOWS_TYPES__
#define __WINDOWS_TYPES__

#include <stdarg.h>
#include "windef.h"
#include "winbase.h"
typedef const char				*LPCTSTR;

#endif
